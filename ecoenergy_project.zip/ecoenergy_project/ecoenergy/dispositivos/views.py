from django.shortcuts import render, get_object_or_404
from .models import Device, Measurement, Alert, Category, Zone
from django.utils import timezone
from django.db.models import Count
from django.db import models

def dashboard(request):
    last_measurements = Measurement.objects.order_by('-timestamp')[:10]
    devices_by_category = Category.objects.all().values("name").annotate(count=models.Count("device"))
    devices_by_zone = Zone.objects.all().values("name").annotate(count=models.Count("device"))
    alerts_week = Alert.objects.filter(
        created_at__week=timezone.now().isocalendar()[1])

    context = {
        "last_measurements": last_measurements,
        "devices_by_category": devices_by_category,
        "devices_by_zone": devices_by_zone,
        "alerts_week": alerts_week,
    }
    return render(request, "dashboard.html", context)


def device_list(request):
    category_id = request.GET.get("category")
    devices = Device.objects.all()
    if category_id:
        devices = devices.filter(category_id=category_id)
    categories = Category.objects.all()
    return render(request, "devices.html", {
        "devices": devices, "categories": categories})


def device_detail(request, pk):
    device = get_object_or_404(Device, pk=pk)
    measurements = Measurement.objects.filter(device=device).order_by("-timestamp")
    alerts = Alert.objects.filter(device=device)
    return render(request, "device_detail.html", {
        "device": device,
        "measurements": measurements,
        "alerts": alerts
    })


def measurement_list(request):
    measurements = Measurement.objects.order_by("-timestamp")[:50]
    return render(request, "measurements.html", {"measurements": measurements})


def alert_list(request):
    alerts = Alert.objects.order_by("-created_at")
    return render(request, "alerts.html", {"alerts": alerts})

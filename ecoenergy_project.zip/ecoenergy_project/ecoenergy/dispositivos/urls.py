from django.urls import path
from . import views

urlpatterns = [
    path("", views.dashboard, name="dashboard"),
    path("devices/", views.device_list, name="device_list"),
    path("devices/<int:pk>/", views.device_detail, name="device_detail"),
    path("measurements/", views.measurement_list, name="measurement_list"),
    path("alerts/", views.alert_list, name="alert_list"),
]

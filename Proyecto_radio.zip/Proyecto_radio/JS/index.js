const player = document.getElementById("radioPlayer");
const playBtn = document.getElementById("playBtn");
const pauseBtn = document.getElementById("pauseBtn");
const backBtn = document.getElementById("backBtn");
const forwardBtn = document.getElementById("forwardBtn");
const volumeControl = document.getElementById("volumeControl");

let isPlaying = false;

// 🎧 PLAY / PAUSE
playPauseBtn.addEventListener("click", () => {

    if (!isPlaying) {
        player.src = "http://sonic.portalfoxmix.club/8128/stream";
        player.play();

        playPauseBtn.classList.add("playing");
        isPlaying = true;

    } else {
        player.pause();

        playPauseBtn.classList.remove("playing");
        isPlaying = false;
    }

});

// 🔊 VOLUMEN
volumeControl.addEventListener("input", () => {
    player.volume = volumeControl.value;
});
// 💬 CHAT
const form = document.getElementById("chat-form");
const input = document.getElementById("chat-input");
const messages = document.getElementById("messages");

form.addEventListener("submit", (e) => {
    e.preventDefault();

    const msg = input.value;

    const div = document.createElement("div");
    div.textContent = msg;

    messages.appendChild(div);
    messages.scrollTop = messages.scrollHeight;

    input.value = "";
});
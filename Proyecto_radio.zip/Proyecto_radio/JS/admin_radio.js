// 🔐 LOGIN SIMPLE
function login() {
    const pass = document.getElementById("password").value;

    if (pass === "1234") {
        document.getElementById("loginBox").classList.add("d-none");
        document.getElementById("adminPanel").classList.remove("d-none");

        loadNews();
    } else {
        alert("Contraseña incorrecta");
    }
}

// 📰 AGREGAR NOTICIA
function addNews() {
    const input = document.getElementById("newsInput");
    let news = JSON.parse(localStorage.getItem("news")) || [];

    news.push(input.value);
    localStorage.setItem("news", JSON.stringify(news));

    input.value = "";
    loadNews();
}

// 📋 MOSTRAR NOTICIAS
function loadNews() {
    const list = document.getElementById("newsList");
    let news = JSON.parse(localStorage.getItem("news")) || [];

    list.innerHTML = "";

    news.forEach((n, i) => {
        const li = document.createElement("li");
        li.innerHTML = `
            ${n} 
            <button onclick="deleteNews(${i})" class="btn btn-sm btn-danger">X</button>
        `;
        list.appendChild(li);
    });
}

// ❌ BORRAR NOTICIA
function deleteNews(index) {
    let news = JSON.parse(localStorage.getItem("news")) || [];

    news.splice(index, 1);
    localStorage.setItem("news", JSON.stringify(news));

    loadNews();
}

// 🧹 BORRAR CHAT
function clearChat() {
    localStorage.removeItem("chat");
    alert("Chat borrado");
}
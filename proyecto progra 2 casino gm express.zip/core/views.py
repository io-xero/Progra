from django.shortcuts import redirect, render
from django.contrib.auth.decorators import login_required

def login_redirect(request):
    return redirect('login')

@login_required
def dashboard(request):
    return render(request, 'core/dashboard.html')

from django.contrib import admin
from .models import Company, Branch
@admin.register(Company)
class CompanyAdmin(admin.ModelAdmin):
    list_display = ('name','created_at')
@admin.register(Branch)
class BranchAdmin(admin.ModelAdmin):
    list_display = ('name','company','address')

from django.db import models
from core.models import TimestampedModel
from organizations.models import Branch
from inventory.models import StockItem
from django.contrib.auth import get_user_model
User = get_user_model()

class Rental(TimestampedModel):
    stock_item = models.ForeignKey(StockItem, on_delete=models.PROTECT, related_name='rentals')
    user = models.ForeignKey(User, on_delete=models.SET_NULL, null=True)
    start_date = models.DateField()
    end_date = models.DateField()
    returned = models.BooleanField(default=False)
    branch = models.ForeignKey(Branch, on_delete=models.CASCADE)
    def __str__(self): return f'Rental {self.stock_item} for {self.user}'

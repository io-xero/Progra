Casino GM Express - starter project (editable)

How to run (Windows + WAMP):
1. cd to project folder (where manage.py is)
2. python -m venv .venv
3. .venv\Scripts\activate
4. pip install -r requirements.txt
5. create database in MySQL: CREATE DATABASE gmexpress_db CHARACTER SET utf8mb4;
6. python manage.py makemigrations
7. python manage.py migrate
8. python manage.py seed_demo
9. python manage.py bootstrap_users
10. python manage.py runserver

Default users:
- admin / admin123
- bodeguero1 / bodeguero1pass
- vendedor1 / vendedor1pass

from django.db import models
from core.models import TimestampedModel
from organizations.models import Branch

class Category(TimestampedModel):
    name = models.CharField(max_length=150)
    def __str__(self): return self.name

class Product(TimestampedModel):
    name = models.CharField(max_length=200)
    sku = models.CharField(max_length=80, unique=True)
    category = models.ForeignKey(Category, on_delete=models.PROTECT, related_name='products')
    is_rentable = models.BooleanField(default=False)
    is_sellable = models.BooleanField(default=True)
    def __str__(self): return self.name

class StockItem(TimestampedModel):
    branch = models.ForeignKey(Branch, on_delete=models.CASCADE, related_name='stock_items')
    product = models.ForeignKey(Product, on_delete=models.CASCADE, related_name='stock_items')
    quantity = models.IntegerField(default=0)
    serial_number = models.CharField(max_length=120, blank=True, null=True)
    status = models.CharField(max_length=30, default='AVAILABLE')
    class Meta:
        unique_together = ('branch','product','serial_number')
    def __str__(self): return f'{self.product} @ {self.branch}'

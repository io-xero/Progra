from django.core.management.base import BaseCommand
from organizations.models import Company, Branch
from inventory.models import Category, Product, StockItem

class Command(BaseCommand):
    help = "Crea datos demo"

    def handle(self, *args, **kwargs):
        company, _ = Company.objects.get_or_create(name='Casino GM Express')
        branch, _ = Branch.objects.get_or_create(company=company, name='Bodega Central')
        c1, _ = Category.objects.get_or_create(name='Alimentos')
        c2, _ = Category.objects.get_or_create(name='Implementos de Cocina')
        p1, _ = Product.objects.get_or_create(name='Salsa Tomate 1L', sku='AL-001', category=c1, is_sellable=True)
        p2, _ = Product.objects.get_or_create(name='Olla 50L', sku='IM-100', category=c2, is_rentable=True, is_sellable=True)
        StockItem.objects.get_or_create(branch=branch, product=p1, quantity=200)
        StockItem.objects.get_or_create(branch=branch, product=p2, quantity=5, serial_number='SN-OLLA-001')
        self.stdout.write(self.style.SUCCESS('Seed demo OK'))

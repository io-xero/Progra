from django.contrib import admin
from .models import Category, Product, StockItem
@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ('name','created_at')
@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = ('name','sku','category')
@admin.register(StockItem)
class StockItemAdmin(admin.ModelAdmin):
    list_display = ('product','branch','quantity','status')

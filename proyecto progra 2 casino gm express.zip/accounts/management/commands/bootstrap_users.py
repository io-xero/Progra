from django.core.management.base import BaseCommand
from django.contrib.auth.models import Group, User
from organizations.models import Company, Branch, UserProfile

class Command(BaseCommand):
    help = "Crear grupos y usuarios demo"

    def handle(self, *args, **kwargs):
        group_admin, _ = Group.objects.get_or_create(name='AdminFull')
        group_bodeguero, _ = Group.objects.get_or_create(name='Bodeguero')
        group_vendedor, _ = Group.objects.get_or_create(name='Vendedor')

        company, _ = Company.objects.get_or_create(name='Casino GM Express')
        branch, _ = Branch.objects.get_or_create(company=company, name='Bodega Central')

        if not User.objects.filter(username='admin').exists():
            User.objects.create_superuser('admin','admin@gmexpress.local','admin123')
            self.stdout.write('Superuser creado: admin/admin123')

        if not User.objects.filter(username='bodeguero1').exists():
            u = User.objects.create_user('bodeguero1','bodeguero1@gmexpress.local','bodeguero1pass', is_staff=True)
            u.groups.add(group_bodeguero)
            UserProfile.objects.create(user=u, branch=branch, role='Bodeguero')
            self.stdout.write('Usuario bodeguero creado: bodeguero1 / bodeguero1pass')

        if not User.objects.filter(username='vendedor1').exists():
            u = User.objects.create_user('vendedor1','vendedor1@gmexpress.local','vendedor1pass', is_staff=True)
            u.groups.add(group_vendedor)
            UserProfile.objects.create(user=u, branch=branch, role='Vendedor')
            self.stdout.write('Usuario vendedor creado: vendedor1 / vendedor1pass')
